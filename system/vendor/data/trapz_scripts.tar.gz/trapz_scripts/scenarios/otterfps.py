from statemachine import StateMachine

class OtterFpsStateMachine(StateMachine):
    NAME = "OtterFps"
    DESCRIPTION = "Calculate running FPS counter on Otter platform"

    # Add VCD trace counting occurances in last 1 sec
    COUNT_INTERVAL = 1

    def START__DssDriver_FlipCmdFinish(self, event):
        return StateMachine.FINISHED
